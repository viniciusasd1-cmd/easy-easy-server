// ============================================
// BACKGROUND.JS - EASY&EASY
// ============================================

'use strict';

const DEFAULT_API_BASE_URL = 'https://easy-easy-server.onrender.com';
const CHECK_INTERVAL_MINUTES = 5;
const CHECK_ALARM_NAME = 'easyEasyCheckLicense';
const REQUEST_TIMEOUT_MS = 12000;

let verificationInProgress = null;

function chromeCall(invoke) {
  return new Promise((resolve, reject) => {
    invoke((result) => {
      if (chrome.runtime.lastError) {
        reject(new Error(chrome.runtime.lastError.message));
        return;
      }
      resolve(result);
    });
  });
}

async function getStorage(keys = null) {
  return chromeCall((done) => chrome.storage.local.get(keys, done));
}

async function setStorage(values) {
  await chromeCall((done) => chrome.storage.local.set(values, done));
}

async function removeStorage(keys) {
  await chromeCall((done) => chrome.storage.local.remove(keys, done));
}

async function getDeviceId() {
  const stored = await getStorage(['deviceId']);
  if (stored.deviceId) return stored.deviceId;

  const deviceId = crypto.randomUUID();
  await setStorage({ deviceId });
  return deviceId;
}

async function getApiBaseUrl() {
  const { apiBaseUrl } = await getStorage(['apiBaseUrl']);
  const candidate = String(apiBaseUrl || DEFAULT_API_BASE_URL).replace(/\/$/, '');

  if (
    candidate.startsWith('https://') ||
    /^http:\/\/(localhost|127\.0\.0\.1)(:\d+)?$/.test(candidate)
  ) {
    return candidate;
  }

  return DEFAULT_API_BASE_URL;
}

async function apiRequest(path, options = {}) {
  const baseUrl = await getApiBaseUrl();
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), REQUEST_TIMEOUT_MS);

  try {
    const response = await fetch(`${baseUrl}${path}`, {
      ...options,
      headers: {
        Accept: 'application/json',
        ...(options.body ? { 'Content-Type': 'application/json' } : {}),
        ...options.headers,
      },
      signal: controller.signal,
    });

    const data = await response.json().catch(() => ({}));
    if (!response.ok) {
      const error = new Error(data.error || data.msg || `Erro HTTP ${response.status}`);
      error.status = response.status;
      error.code = data.code;
      throw error;
    }

    return data;
  } catch (error) {
    if (error.name === 'AbortError') {
      throw new Error('O servidor demorou para responder');
    }
    if (error instanceof TypeError) {
      throw new Error('Servidor indisponível');
    }
    throw error;
  } finally {
    clearTimeout(timeout);
  }
}

async function saveLicenseResult(licenseKey, result) {
  await setStorage({
    licenseKey: licenseKey.trim().toUpperCase(),
    keyValid: true,
    authStatus: 'success',
    authMsg: result.msg || 'Licença válida',
    user: result.user || 'Usuário',
    userName: result.user || 'Usuário',
    validade: result.validade ?? null,
    plan: result.plan || '',
    enabled: true,
  });
}

async function activateLicense(licenseKey) {
  const key = String(licenseKey || '').trim().toUpperCase();
  if (!key) throw new Error('Informe uma chave de licença');

  const deviceId = await getDeviceId();
  const result = await apiRequest('/api/activate', {
    method: 'POST',
    body: JSON.stringify({
      licenseKey: key,
      deviceId,
      userAgent: navigator.userAgent,
    }),
  });

  await saveLicenseResult(key, result);
  await notifyConfigChanged();
  return result;
}

async function runStoredVerification() {
  const stored = await getStorage(['licenseKey']);
  if (!stored.licenseKey) {
    await setStorage({
      keyValid: false,
      authStatus: 'error',
      authMsg: 'Nenhuma licença ativada',
      enabled: false,
    });
    return { success: false, msg: 'Nenhuma licença ativada' };
  }

  try {
    const deviceId = await getDeviceId();
    const result = await apiRequest('/api/validate', {
      method: 'POST',
      body: JSON.stringify({
        licenseKey: stored.licenseKey,
        deviceId,
        userAgent: navigator.userAgent,
      }),
    });
    await saveLicenseResult(stored.licenseKey, result);
    await notifyConfigChanged();
    return { success: true, data: result };
  } catch (error) {
    await setStorage({
      keyValid: false,
      authStatus: 'error',
      authMsg: error.message,
      enabled: false,
    });
    await notifyConfigChanged();
    return { success: false, msg: error.message };
  }
}

function verifyStoredLicense() {
  if (verificationInProgress) return verificationInProgress;
  verificationInProgress = runStoredVerification().finally(() => {
    verificationInProgress = null;
  });
  return verificationInProgress;
}

async function getStatus() {
  const stored = await getStorage([
    'licenseKey',
    'keyValid',
    'authStatus',
    'authMsg',
    'user',
    'validade',
    'plan',
    'enabled',
    'mode',
    'showValidity',
    'pendingPaymentId',
  ]);

  return {
    licenseKey: stored.licenseKey || '',
    keyValid: stored.keyValid === true,
    authStatus: stored.authStatus || '',
    authMsg: stored.authMsg || '',
    user: stored.user || '',
    validade: stored.validade ?? null,
    plan: stored.plan || '',
    enabled: stored.enabled === true,
    mode: stored.mode === '2' ? '2' : '1',
    showValidity: stored.showValidity !== false,
    pendingPaymentId: stored.pendingPaymentId || '',
  };
}

async function notifyConfigChanged() {
  const status = await getStatus();
  chrome.tabs.query({}, (tabs) => {
    if (chrome.runtime.lastError) return;
    for (const tab of tabs) {
      if (typeof tab.id !== 'number') continue;
      chrome.tabs.sendMessage(
        tab.id,
        { type: 'LOVABLE_CONFIG_CHANGED', config: status },
        () => void chrome.runtime.lastError,
      );
    }
  });
}

async function handleMessage(message) {
  switch (message?.action) {
    case 'getPlans':
      return apiRequest('/api/plans');

    case 'createPayment': {
      const response = await apiRequest('/api/create-payment', {
        method: 'POST',
        body: JSON.stringify({
          planId: message.planId,
          userPhone: message.userPhone,
          userName: message.userName,
        }),
      });
      if (response.data?.paymentId) {
        await setStorage({ pendingPaymentId: response.data.paymentId });
      }
      return response;
    }

    case 'checkPayment':
      return apiRequest(
        `/api/check-payment/${encodeURIComponent(message.paymentId)}`,
      );

    case 'activateLicense':
    case 'verifyKey': {
      const data = await activateLicense(message.licenseKey || message.key);
      return { success: true, data };
    }

    case 'getStatus':
      return getStatus();

    case 'setEnabled':
      await setStorage({ enabled: message.value === true });
      return { success: true };

    case 'setMode':
      if (!['1', '2'].includes(message.mode)) {
        return { success: false, msg: 'Modo inválido' };
      }
      await setStorage({ mode: message.mode });
      return { success: true };

    case 'setShowValidity':
      await setStorage({ showValidity: message.value === true });
      return { success: true };

    case 'logout':
      await removeStorage([
        'licenseKey',
        'keyValid',
        'authStatus',
        'authMsg',
        'user',
        'userName',
        'validade',
        'plan',
        'pendingPaymentId',
      ]);
      await setStorage({ enabled: false });
      await notifyConfigChanged();
      return { success: true };

    case 'reload_extension':
      setTimeout(() => chrome.runtime.reload(), 100);
      return { success: true };

    default:
      return { success: false, msg: 'Ação desconhecida' };
  }
}

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  handleMessage(message)
    .then(sendResponse)
    .catch((error) => {
      console.error('EASY&EASY background:', error);
      sendResponse({
        success: false,
        error: error.message || 'Erro interno da extensão',
        msg: error.message || 'Erro interno da extensão',
        code: error.code,
      });
    });
  return true;
});

chrome.runtime.onInstalled.addListener(() => {
  chrome.alarms.create(CHECK_ALARM_NAME, {
    periodInMinutes: CHECK_INTERVAL_MINUTES,
  });
  void verifyStoredLicense();
});

chrome.runtime.onStartup.addListener(() => {
  chrome.alarms.create(CHECK_ALARM_NAME, {
    periodInMinutes: CHECK_INTERVAL_MINUTES,
  });
  void verifyStoredLicense();
});

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === CHECK_ALARM_NAME) void verifyStoredLicense();
});

chrome.storage.onChanged.addListener((changes, areaName) => {
  if (areaName !== 'local') return;
  if (['enabled', 'mode', 'showValidity'].some((key) => key in changes)) {
    void notifyConfigChanged();
  }
});

console.log('🚀 Background EASY&EASY iniciado');
